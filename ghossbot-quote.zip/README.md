# GhossBot Quote API

API independiente para generar imágenes estilo "Make it a Quote".

## Endpoint

POST `/quote`

JSON:

```json
{
  "text": "Este es un mensaje de ejemplo",
  "username": "Usuario",
  "avatar": "https://cdn.discordapp.com/avatars/..."
}
```

La respuesta es una imagen PNG.

## Deploy rápido en Render

1. Subí estos archivos a un repositorio de GitHub.
2. En Render elegí **New > Web Service**.
3. Conectá el repositorio.
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Una vez desplegado, la URL será parecida a:
   `https://ghossbot-quote.onrender.com`

El endpoint final será:

`https://ghossbot-quote.onrender.com/quote`

## Importante

GitHub almacena el código; Render ejecuta la API.
